@extends('layouts.admin') 

@section('title')
Kelola Data SIP - Ubah
@endsection

@section('style')
<link rel="stylesheet" href="{{ asset('theme/node_modules/select2/dist/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('theme/node_modules/summernote/dist/summernote-bs4.css') }}">
<style>
    /* .select2-container--default .select2-selection--single {
    background-color: #F5F3FF !important;
    border-color: #C4B5FD !important;
    padding-top: 6px !important;
    font-weight:500 !important;
} */
.note-editor.note-frame {
    border: 1px solid #C4B5FD;
}
.modal-backdrop {
        z-index: 0;
}
.dropdown-toggle::after {
    display: none !important;
}
</style>

@endsection

@section('subheader')
<div class="row">
    <div class="col-1 my-auto">
        <i class="fas fa-tasks font-24"></i>
    </div>
    <div class="col-11">
        <div class="mb-1 text-dark"><h4 class="d-inline">Kelola Data SIP</h4> 
            <span class="ml-2 font-10 badge badge-dark align-top py-1 px-2">Ubah</span>
        
            <div class="btn-group  align-top ml-2 mr-2" title="Menu">
                <a type="button" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-ellipsis-h text-primary"></i>
                </a>
                <div class="dropdown-menu">
                    <a href="{{ route('sip_create')}}" class="text-success dropdown-item" title="Buat SIP Baru"><i class="fas fa-plus mr-2 font-12"></i>Baru 
                    </a>
                    <a href="{{ route('sip_detail', $sip->id)}}" class="text-primary dropdown-item" title="Lihat Detail SIP"><i class="far fa-file-alt  mr-2 font-12"></i>Detail
                    </a>
                </div>
            </div>
        </div>
            
        <span class="font-weight-500 text-primary">Ubah Data SIP  
            <i class="fas fa-edit align-top ml-2"></i>
        </span>
    </div>
</div>
@endsection

@section('breadcrumb')
<a href="{{ route('dashboard')}}"><u>Dashboard</u></a>
<i class="fas fa-angle-right mx-2"></i>
<a href="{{ route('sip_index')}}"><u>SIP</u></a>
<i class="fas fa-angle-right mx-2"></i>
<span class="font-weight-500">Ubah</span>



@endsection

@section('content')

@include('global.notifikasi')

<form method="post" action="{{ route('sip_update', $sip->id)}}" enctype="multipart/form-data">
@csrf

<input type="hidden" name="nmTipe" value="edit">
<input type="hidden" name="idSip" value="{{ $sip->id }}">

<div class="card shadow  border-top5 border-ungu">
    <div class="card-body">
        <div class="row mt-3">
            <div class="col-md-8">
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-15 font-weight-bold text-dark mb-2">No. SIP</div>
                    <div class="col-md-9">
                        <input type="text" id="nmNoSip" name="nmNoSip" 
                        class="form-control h-45 border-form bg-form font-weight-500" 
                        value="{{ $sip->no_sip }}">
                    <small class="text-danger">{{ $errors->first('nmNoSip') }}</small>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-16 font-weight-bold text-dark mb-2">Perusahaan</div>
                    <div class="col-md-9">
                        <select name="nmPerusahaan" id="nmPerusahaan" class="form-control select2 bg-dark" >
                            @foreach ($perusahaan as $per)
                                <option value="{{ $per->id}}" @if($per->id === $sip->perusahaan_id) selected @endif>{{ $per->nama }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-16 font-weight-bold text-dark mb-2">P. Agency</div>
                    <div class="col-md-9">
                    <input type="text" id="nmAgency" name="nmAgency" 
                        class="form-control h-45 border-form bg-form font-weight-500" 
                        value="{{ $sip->agency }}">
                        <small class="text-danger">{{ $errors->first('nmAgency') }}</small>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-16 font-weight-bold text-dark mb-2">Jabatan</div>
                    <div class="col-md-9">
                        <select name="nmJabatan" id="nmJabatan" class="form-control select2">
                            @foreach ($jabatan as $jab)
                            <option value="{{ $jab->id}}" @if($jab->id === $sip->jabatan_id) selected @endif>{{ $jab->nama }}</option>
                        @endforeach
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 font-16 my-1 font-weight-bold text-dark">
                        Status
                    </div>
                    <div class="col-md-9 my-1 font-weight-bold text-dark">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rdFormal" name="nmStatusFormal" class="custom-control-input" value="0" @if($sip->sts_formal === 0) checked @endif>
                                <label class="custom-control-label" for="rdFormal">Formal</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rdInformal" name="nmStatusFormal" class="custom-control-input" value="1" @if($sip->sts_formal === 1) checked @endif>
                                <label class="custom-control-label" for="rdInformal">Informal</label>
                            </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-16 font-weight-bold text-dark mb-2">Negara Tujuan</div>
                    <div class="col-md-9">
                        <select name="nmNegara" id="nmNegara" class="form-control select2">
                            @foreach ($negara as $neg)
                                <option value="{{ $neg->id}}" @if($neg->id === $sip->negara_id) selected @endif>{{ $neg->negara }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-3 mt-2 font-16 font-weight-bold text-dark mb-2">Keterangan</div>
                    <div class="col-md-9">
                        <textarea id="summernote" name="nmKeterangan" class="summernote">{{ $sip->keterangan }}</textarea>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="font-weight-bold font-15 text-dark mb-2">Jumlah Laki-Laki</div>
                    <input type="text" id="nmJumlahL" name="nmJumlahL" 
                        class="form-control h-45 border-form bg-form font-weight-500" value="{{ $sip->jumlah_l }}">
                        <small class="text-danger">{{ $errors->first('nmJumlahL') }}</small>
                </div>
                <div class="form-group">
                    <div class="font-weight-bold font-15 text-dark mb-2">Jumlah Perempuan</div>
                    <input type="text" id="nmJumlahP" name="nmJumlahP" 
                        class="form-control h-45 border-form bg-form font-weight-500" value="{{ $sip->jumlah_p }}">
                        <small class="text-danger">{{ $errors->first('nmJumlahP') }}</small>
                </div>
                <div class="form-group">
                    <div class="font-weight-bold font-15 text-dark mb-2">Jumlah Laki-Laki / Perempuan</div>
                    <input type="text" id="nmJumlahLP" name="nmJumlahLP" 
                        class="form-control h-45 border-form bg-form font-weight-500" value="{{ $sip->jumlah_lp }}">
                        <small class="text-danger">{{ $errors->first('nmJumlahLP') }}</small>
                </div>
                <div class="form-group">
                    <div class="font-weight-bold font-15 text-dark mb-2">Tanggal Berlaku Ijin</div>
                    <input type="date" id="nmIjinAwal" name="nmIjinAwal" 
                        class="form-control h-45 border-form bg-form font-weight-500" value="{{ $sip->tgl_ijin_awal }}">
                        <small class="text-danger">{{ $errors->first('nmIjinAwal') }}</small>
                </div>
                <div class="form-group">
                    <div class="font-weight-bold font-15 text-dark mb-2">Tanggal Ijin Berakhir</div>
                    <input type="date" id="nmIjinAkhir" name="nmIjinAkhir" 
                        class="form-control h-45 border-form bg-form font-weight-500" value="{{ $sip->tgl_ijin_akhir }}">
                        <small class="text-danger">{{ $errors->first('nmIjinAkhir') }}</small>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer text-center border-top">
        <button type="submit" class="btn btn-lg btn-dark">
            <span class="font-16"><i class="fas fa-check mr-2"></i>Perbarui</span>
        </button>
    </div>
</div>

</form>

@endsection


@section('script')

<script src="{{ asset('theme/node_modules/summernote/dist/summernote-bs4.js') }}"></script>
<script src="{{ asset('theme/node_modules/select2/dist/js/select2.full.min.js') }}"></script>
<script>
    
    $('#summernote').summernote({
    toolbar: [
    // [groupName, [list of button]]
    ['style', ['bold', 'italic', 'underline', 'clear']],
    ['font', ['strikethrough', 'superscript']],
    ['fontsize', ['fontsize']],
    ['color', ['color']],
    ['para', ['ul', 'ol', 'paragraph']],
    ['table', ['table']],
    ['insert', ['link', 'picture']],
    ['view', ['codeview', 'help']],
    ['height', ['height']]
    ],
    height: 200
});
</script>

@endsection