@extends('layouts.admin') 

@section('title')
Kelola Data Perusahaan - Detail
@endsection

@section('style')
<style>
    .dropdown-toggle::after {
    display: none !important;
}
</style>
@endsection

@section('subheader')
<div class="row">
    <div class="col-1 my-auto">
        <i class="fas fa-tasks font-24"></i>
    </div>
    <div class="col-11">
        <div class="mb-1 text-dark"><h4 class="d-inline">Kelola Data Perusahaan</h4> 
            <span class="ml-2 font-10 badge badge-dark align-top py-1 px-2">Detail</span>
            <div class="btn-group  align-top ml-2 mr-2" title="Menu">
                <a type="button" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-ellipsis-h text-primary"></i>
                </a>
                <div class="dropdown-menu">
                    <a href="{{ route('perusahaan_create')}}" class="text-success dropdown-item" title="Buat Perusahaan Baru"><i class="fas fa-plus mr-2 font-12"></i>Baru 
                    </a>
                    <a href="{{ route('perusahaan_edit', $perusahaan->id)}}" class="text-primary dropdown-item" title="Ubah Data Perusahaan"><i class="far fa-file-alt  mr-2 font-12"></i>Ubah
                    </a>
                </div>
            </div>
        </div>
            
        <span class="font-weight-500 text-primary">Detail Perusahaan <i class="far fa-file-alt ml-2"></i></span>
        
    </div>
</div>
@endsection

@section('breadcrumb')
<a href="{{ route('dashboard')}}"><u>Dashboard</u></a>
<i class="fas fa-angle-right mx-2"></i>
<a href="{{ route('perusahaan_index')}}"><u>Perusahaan</u></a>
<i class="fas fa-angle-right mx-2"></i>
<span class="font-weight-500">{{ $perusahaan->nama }}</span>
@endsection

@section('content')

@include('global.notifikasi')

<div class="card shadow  border-top5 border-ungu">
    <div class="card-body mb-4">
        <div class="row mb-2">
            <div class="col-md-12 text-right">
                <a href="{{ route('perusahaan_edit', $perusahaan->id)}}" class="btn btn-dark">
                    <span class="font-14"><i class="fas fa-edit mr-2"></i>Ubah</span>
                </a>
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Nama Perusahaan</div>
            <div class="py-2 col-9 font-weight-bold text-primary">
                {{ $perusahaan->nama }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Alamat</div>
            <div class="py-2 col-9 font-weight-500 text-dark">
                {{ $perusahaan->alamat }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Kab. / Kota</div>
            <div class="py-2 col-9 font-weight-500 text-dark">
                {{ $kabupaten }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Provinsi</div>
            <div class="py-2 col-9 font-weight-500 text-dark">
                {{ $provinsi }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Kontak (Telp.)</div>
            <div class="py-2 col-9 font-weight-500">
                {{ $perusahaan->contact_telp }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Email</div>
            <div class="py-2 col-9 font-weight-500">
                {{ $perusahaan->email?:"-" }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Contact Person</div>
            <div class="py-2 col-9 font-weight-500">
                {{ $perusahaan->contact_nama?:"-" }}
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">Login Sistem</div>
            <div class="py-2 col-9 font-weight-500">
                @if($perusahaan->user_id)
                    <i class="font-18 far fa-check-circle text-success" title="Ya"></i>
                @else
                    <i class="font-18 far fa-times-circle text-danger" title="Tidak"></i>
                @endif
            </div>
        </div>
        <div class="form-group row my-0">
            <div class="py-2 col-3 font-15 font-weight-bold text-dark text-right border-right2">SIP</div>
            <div class="py-2 col-9">
                    @if(count($sip) > 0)
                        <ol class="pl-3">
                            @foreach($sip as $x)
                                <li class="pb-2">
                                    <a class="font-weight-bold border-bottom border-primary" href="{{ route('sip_detail' , $x->id)}}" target="_blank">
                                        {{ $x->no_sip }}
                                    </a>
                                    <div class="font-12 font-weight-500">
                                        <u class="text-dark">Berlaku</u>: {{ $x->tgl_ijin_awal }} 
                                        <span class="mx-1">hingga</span>{{ $x->tgl_ijin_akhir }}
                                    </div>
                                </li>
                            @endforeach
                        </ol>
                    @else
                        Belum mempunyai data SIP
                    @endif
            </div>
        </div>
    </div>
</div>


@endsection
