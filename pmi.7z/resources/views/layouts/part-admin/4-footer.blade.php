<footer class="main-footer">
    <div class="footer-left">
      Crafted By <a href="https://pelitacipta.com/">Pelita Cipta Informatika</a>
    </div>
    <div class="footer-right">
        simpadupmi 2.0
    </div>
</footer>