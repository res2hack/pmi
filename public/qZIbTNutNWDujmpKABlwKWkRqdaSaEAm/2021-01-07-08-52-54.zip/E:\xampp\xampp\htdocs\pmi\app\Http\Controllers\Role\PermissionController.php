<?php

namespace App\Http\Controllers\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;

class PermissionController extends Controller
{

    

    public function dataPermission(){
        $permission = DB::table('permissions')->select('id', 'name', 'deskripsi')->get();
        return $permission;
    }

    public function index()
    {
        $permission = $this->dataPermission();
        return view('users.permission.index', [
            'permission' => $permission
        ]);
    }

    public function store(Request $request)
    {
        $name = $request->nama;
        $deskripsi = $request->deskripsi;
        Permission::create([
            'name' => $name,
            'guard_name' => 'web',
            'deskripsi' => $deskripsi,
            ]);
        return redirect()->back();
    }

    public function edit($id)
    {
        $permission = Permission::find($id);
        return view('users.permission.edit', [
            'permission' => $permission
        ]);
    }

    public function update(Request $request, $id)
    {
        Permission::find($id)->update([
            'name' => $request->nmPermission,
            'deskripsi' => $request->nmDeskripsi,
            'guard_name' => 'web'
            ]);

        return redirect()->back();
    }

    public function delete_index(Request $request)
    {
        Permission::find($request->idDelete)->delete();
        return redirect()->back();
    }
}
