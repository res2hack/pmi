<?php

namespace App\Http\Controllers\Role;
use App\Http\Controllers\Controller;

use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Arr;
class RoleController extends Controller
{

    public function index()
    {
        $roles = Role::get();
        $permissions = Permission::get();
        $role_permissions = DB::table('role_has_permissions')
                    ->select('role_has_permissions.*', 'permissions.name')
                    ->leftjoin('permissions', 'permissions.id', '=', 'role_has_permissions.permission_id')
                    ->get();
        $role_permissions = arr::flatten($role_permissions);
        // dd($role_permissions);
        return view('users.role.index', [
            'roles' => $roles,
            'permissions' => $permissions,
            'role_permissions' => $role_permissions,
        ]);
    }

    public function create()
    {
        $roles = Role::get();
        $permissions = Permission::get();
        return view('users.role.create', [
            'roles' => $roles,
            'permissions' => $permissions,
        ]);
    }

    public function edit($id)
    {
        $role = Role::find($id);
        $role_permissions = DB::table('role_has_permissions')->where('role_id', $id)->pluck('permission_id');
        $role_permissions = arr::flatten($role_permissions);
        $permissions = DB::table('permissions')->select('id', 'name', 'deskripsi')->get();
    
        return view('users.role.edit', [
            'role' => $role,
            'role_permissions' => $role_permissions,
            'permissions' => $permissions,
        ]);
    }

    public function store(Request $request)
    {
    
        $role_create = Role::create([
            'name' => $request->nmRole,
            'deskripsi' => $request->nmDeskripsi,
            'guard_name' => 'web'
            ]);
        $permission = $request->nmPermission;
        if($permission){
            foreach($permission as $x => $value){
                $role_create->givePermissionTo($value);
            }
        }
        
        return redirect()->back();
    }

    public function update(Request $request, $id)
    {
    
        // $role_update = Role::find($id);
        $role_update = Role::find($id)->update([
            'name' => $request->nmRole,
            'deskripsi' => $request->nmDeskripsi,
            'guard_name' => 'web'
            ]);

        DB::table('role_has_permissions')
            ->where('role_id', $id)
            ->delete();

        $permission = $request->nmPermission;
        if($permission){
            foreach($permission as $x => $value){
                Role::find($id)->givePermissionTo($value);
            }
        }
        
        return redirect()->back();
    }

    public function delete_index(Request $request)
    {
        Role::find($request->idDelete)->delete();
        return redirect()->back();
    }


}
