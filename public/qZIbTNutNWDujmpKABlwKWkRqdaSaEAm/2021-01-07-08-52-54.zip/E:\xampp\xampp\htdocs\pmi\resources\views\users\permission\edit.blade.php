@extends('layouts.admin') 

@section('title')
Edit Hak Akses
@endsection

@section('content')
<form method="POST" action="{{ route('permission_update', $permission->id )}}">
    @csrf

    <div class="row">
        <div class="col-4">
            
            <div class="card">
                <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                    Edit Hak Akses
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Nama Hak Akses</label>
                    <input type="text" name="nmPermission" class="form-control" value="{{ $permission->name }}" required>
                    </div>
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Deskripsi</label>
                        <textarea type="text" name="nmDeskripsi" class="p-3 
                        border d-block w-100 rounded bg-form1 border-form1" rows="5">{{ $permission->deskripsi }}</textarea>
                    </div>
                </div>
                <div class="card-footer py-3 bg-light">
                    <button type="submit" class="btn btn-dark">Perbarui</button>
                </div>
            </div>
            
        </div>
        
    </div>
</form>
@endsection