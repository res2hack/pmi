@extends('layouts.admin') 

@section('title')
Kelola Data User
@endsection

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="text-right mb-3"> 
                        <a href="{{ route('user_create')}}" class="btn btn-dark">Baru</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr class="bg-secondary">
                                    <th class="h-50 py-3 text-white">Nama User</th>
                                    <th class="h-50 py-3 text-white">Role</th>
                                    <th class="h-50 py-3 text-white"></th>
                                </tr>
                            </thead>
                            <tbody> 
                                <tr>
                                    <td colspan="4" class="pt-2 h-50"></td>
                                </tr>
                                @foreach($users as $x)
                                <tr>
                                    <td class=" bg-plum4 h-50 py-2">
                                    <a href="{{ route('user_edit', $x->id)}}">{{ $x->name }}</a>
                                    </td>
                                    <td class="bg-plum4 h-50 py-2">
                                        @foreach ($roles as $item)
                                            @if($x->id === $item->model_id)
                                                <span class="mr-1 d-inline-block bg-success font-12 rounded py-1 px-2 text-white">
                                                    {{ $item->name }}
                                                </span>
                                            @endif
                                        @endforeach
                                    </td>
                                    <td class="bg-plum4 h-50 py-2"></td>
                                    {{-- <td class=" bg-plum4 h-50 py-2">
                                        <a href="{{ route('role_edit', $x->id )}}"><i class="fas fa-edit"></i></a>
                                        <a href="" onclick="$('#idDelete').val({{ $x->id }});" title="Hapus Bidang" data-toggle="modal" 
                                            data-target="#exampleModalCenter"><i class="fas fa-times text-danger font-15"></i></a>
                                    </td> --}}
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modal')

<form method="POST" action="{{ route('role_delete_index')}}">
    @csrf
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><i class="fas fa-exclamation-triangle font-15 text-warning mr-2"></i> KONFIRMASI</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Anda Yakin Ingin Menghapus Data Ini?
                <input id="idDelete" name="idDelete" type="hidden">
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-secondary" data-dismiss="modal">Batal</a>
                <button type="submit" class="btn btn-danger">Ya Hapus</button>
            </div>
        
            </div>
        </div>

    </div>
</form>
@endsection