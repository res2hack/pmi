@extends('layouts.admin') 

@section('title')
Kelola Hak Akses
@endsection

@section('content')
<form method="HEAD" action="{{ route('user_store')}}">
    @csrf

    <div class="row">
        <div class="col-4">
                <div class="card">
                    <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                        User Baru
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Nama</label>
                            <input name="User" type="text" class="form-control" value="{{ old('User') }}"  >
                            <small class="text-danger font-weight-bold">{{ $errors->first('User') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Email</label>
                            <input name="Email" type="email" class="form-control" value="{{ old('Email') }}" >
                            <small class="text-danger font-weight-bold">{{ $errors->first('Email') }}</small>
                        </div>
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Password</label>
                            <input name="password" type="password" class="form-control" value="{{ old('password') }}" >
                            
                        </div>
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Confirm Password</label>
                            <input name="password_confirmation" type="password" value="{{ old('password_confirmation') }}" class="form-control" >
                            <small class="text-danger font-weight-bold">{{ $errors->first('password') }}</small>
                        </div>
                    </div>
                    <div class="card-footer bg-light py-3">
                        <button type="submit" class="btn btn-dark">Simpan</button>
                    </div>
                </div>
            
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead>
                                <th class="h-50 py-3">Role</th>
                                <th class="h-50 py-3">Deskripsi</th>
                        </thead>
                        <tbody> 
                            <tr>
                                <td class="h-50 py-1"></td>
                            </tr>
                            @foreach ($role as $item)
                            <tr>
                                <td class="h-50 py-1">
                                    <input type="checkbox" name="nmRole[]" value="{{ $item->id }}">
                                    <label class="font-bold-500 text-hitam pl-3">{{ $item->name  }}</label>
                                </td>
                                <td  class="h-50 py-1">
                                    {{ $item->deskripsi }}
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection