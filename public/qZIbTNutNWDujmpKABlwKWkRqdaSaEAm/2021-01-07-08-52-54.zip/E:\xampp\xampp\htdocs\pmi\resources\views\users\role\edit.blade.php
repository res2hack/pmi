@extends('layouts.admin') 

@section('title')
Kelola Role
@endsection

@section('content')
<form method="POST" action="{{ route('role_update', $role->id )}}">
    @csrf

    <div class="row">
        <div class="col-4">
            
            <div class="card">
                <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                    Edit Role
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Role Name</label>
                    <input type="text" name="nmRole" class="form-control" value="{{ $role->name }}" required>
                    </div>
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Deskripsi</label>
                        <textarea type="text" name="nmDeskripsi" class="p-3 
                        border d-block w-100 rounded bg-form1 border-form1" rows="5">{{ $role->deskripsi }}</textarea>
                    </div>
                </div>
                <div class="card-footer py-3 bg-light">
                    <button type="submit" class="btn btn-dark">Perbarui</button>
                </div>
            </div>
            
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="h-50 py-3">Nama Role</th>
                                <th class="h-50 py-3">Deskripsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="h-50 pt-2"></td>
                            </tr>
                            @foreach($permissions as $x)
                            <tr>
                                <td class=" bg-plum4 h-50 py-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="nmPermission[]" 
                                        value="{{ $x->id }}" id="cbPermisi{{ $x->id }}" {{ in_array($x->id, $role_permissions) ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="cbPermisi{{ $x->id }}">{{ $x->name }}</label>
                                    </div>
                                </td>
                                <td class=" bg-plum4 h-50 py-1">
                                    {{ $x->deskripsi }}
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection