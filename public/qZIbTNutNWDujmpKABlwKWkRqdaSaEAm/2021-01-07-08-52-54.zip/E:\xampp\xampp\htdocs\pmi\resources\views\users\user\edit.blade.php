@extends('layouts.admin') 

@section('title')
Kelola Hak Akses
@endsection

@section('content')
<form method="POST" action="{{ route('user_update', $user->id)}}">
    @csrf

    <div class="row">
        <div class="col-4">
                <div class="card">
                    <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                        Edit User
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="" class="font-weight-bold">User</label>
                            <input name="User" type="text" class="form-control" value="{{ $user->name }}">
                        </div>
                        <div class="form-group">
                            <label for="" class="font-weight-bold">Email</label>
                            <input name="Email" type="text" class="form-control" value="{{ $user->email }}">
                        </div>
                        <div class="custom-control custom-checkbox mb-4">
                        <input onclick="gantiPassword();" type="checkbox" @if(old('cbGantiPassword')) checked @endif
                            class="custom-control-input" id="cbGantiPassword" name="cbGantiPassword" >
                            <label class="custom-control-label" for="cbGantiPassword">Ganti Password</label>
                        </div>
                        <div class="form-group gantiPassword" @if(old('cbGantiPassword') === null) style="display:none; @endif">
                            <label for="" class="font-weight-bold">Password Lama</label>
                            <input name="old_password" type="password" class="form-control" value="{{ old('old_password') }}" >
                            <small class="text-danger font-weight-bold">{{ $errors->first('old_password') }}</small>
                        </div>
                        <div class="form-group gantiPassword" @if(old('cbGantiPassword') === null) style="display:none; @endif">
                            <label for="" class="font-weight-bold">Password Baru</label>
                            <input name="new_password" type="password" class="form-control" value="{{ old('new_password') }}" >
                            <small class="text-danger font-weight-bold">{{ $errors->first('new_password') }}</small>
                        </div>
                        <div class="form-group gantiPassword" @if(old('cbGantiPassword') === null) style="display:none; @endif">
                            <label for="" class="font-weight-bold">Confirm Password</label>
                            <input name="new_password_confirmation" type="password" value="{{ old('new_password_confirmation') }}" class="form-control" >
                            <small class="text-danger font-weight-bold">{{ $errors->first('new_password_confirmation') }}</small>
                        </div>
                    </div>
                    <div class="card-footer bg-light py-3">
                        <button type="submit" class="btn btn-dark">Perbarui</button>
                    </div>
                </div>
            
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <table class="table" style="border-spacing: 0; width: 100%;">
                        <thead class="d-none">
                            <tr>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody > 
                            
                            @foreach ($role as $x)
                            <tr>
                                <td class="pl-3 bg-plum4 h-50 py-1">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="nmRole[]" 
                                        value="{{ $x->id }}" id="cbRole{{ $x->id }}" {{ in_array($x->id, $user_roles) ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="cbRole{{ $x->id }}">{{ $x->name }}</label>
                                    </div>
                                </td>
                            </tr>
                            @endforeach

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('script')
<script>
    function gantiPassword() {
    var checkBox = document.getElementById("cbGantiPassword");
    if (checkBox.checked == true){
        $('.gantiPassword').show();
    } else {
        $('.gantiPassword').hide();
    }
}
</script>
@endsection