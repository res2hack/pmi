 

<?php $__env->startSection('title'); ?>
Kelola Hak Akses
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-4">
        <form method="HEAD" action="<?php echo e(route('permission_store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                    Hak Akses Baru
                </div>
                <div class="card-body pb-1">
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Name</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Deskripsi</label>
                        <textarea type="text" name="nmDeskripsi" class="border p-3 d-block w-100 rounded bg-form1 border-form1" rows="5"></textarea>
                    </div>
                </div>
                <div class="card-footer bg-light py-3">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
        </form>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                    <table class="table">
                        <thead>
                            <th class="h-50 py-3">Nama</th>
                            <th class="h-50 py-3">Deskripsi</th>
                            <th class="h-50 py-3"></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="h-50 py-2">
                                    
                                    <?php echo e($x->name); ?>

                                </td>
                                <td class="h-50 py-2"><?php echo e($x->deskripsi); ?></td>
                                <td class="h-50 py-2">
                                    <a class="mr-1" href="<?php echo e(route('permission_edit', $x->id )); ?>"><i class="fas fa-edit"></i></a>
                                    <a href="" onclick="$('#idDelete').val(<?php echo e($x->id); ?>);" title="Hapus Data" data-toggle="modal" data-target="#exampleModalCenter"><i class="fas fa-times text-danger font-15"></i></a>
                                </td>
                                
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
            
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

<form method="POST" action="<?php echo e(route('permission_delete_index')); ?>">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle"><i class="fas fa-exclamation-triangle font-15 text-warning mr-2"></i> KONFIRMASI</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Anda Yakin Ingin Menghapus Data Ini?
                <input id="idDelete" name="idDelete" type="hidden">
            </div>
            <div class="modal-footer">
                <a href="" class="btn btn-secondary" data-dismiss="modal">Batal</a>
                <button type="submit" class="btn btn-danger">Ya Hapus</button>
            </div>
        
            </div>
        </div>

    </div>
</form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\xampp\htdocs\pmi\resources\views/users/permission/index.blade.php ENDPATH**/ ?>