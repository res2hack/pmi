
@if(Auth::user()->tipe === 0)
    @include('layouts.admin') 
@else
    @include('layouts.user')  
@endif