@extends('layouts.admin') 

@section('title')
Kelola Hak Akses
@endsection

@section('content')
<form method="HEAD" action="{{ route('role_store')}}">
    @csrf

    <div class="row">
        <div class="col-4">
            
            <div class="card">
                <div class="card-footer bg-dark text-light font-weight-bold font-16 rounded-top">
                    Role Baru
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Role Name</label>
                        <input type="text" name="nmRole" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="" class="font-weight-bold">Deskripsi</label>
                        <textarea type="text" name="nmDeskripsi" class="p-2 border d-block w-100 rounded bg-form1 border-form1" rows="5"></textarea>
                    </div>
                </div>
                <div class="card-footer py-3 bg-light">
                    <button type="submit" class="btn btn-dark">Simpan</button>
                </div>
            </div>
            
        </div>
        <div class="col-8">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="h-50 py-3">Nama Role</th>
                                <th class="h-50 py-3">Deskripsi</th>
                            </tr>
                        </thead>
                        <tbody> 
                            @foreach($permissions as $x)
                            <tr>
                                <td class=" bg-plum4 h-50 py-2">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="nmPermission[]" value="{{ $x->id }}" id="cbPermisi{{ $x->id }}">
                                        <label class="custom-control-label" for="cbPermisi{{ $x->id }}">{{ $x->name }}</label>
                                    </div>
                                </td>
                                <td class=" bg-plum4 h-50 py-2">
                                    {{ $x->deskripsi }}
                                </td>
                            </tr>
                         
                            @endforeach
                            {{-- @foreach ($permissions as $item)
                            <tr>
                                <td class="pl-3 bg-plum4 h-50 py-2">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="nmPermission[]" value="{{ $item->id }}" id="cbPermisi{{ $item->id }}">
                                        <label class="custom-control-label" for="cbPermisi{{ $item->id }}">{{ $item->name }}</label>
                                    </div>
                                </td>
                            </tr>
                            @endforeach --}}

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection