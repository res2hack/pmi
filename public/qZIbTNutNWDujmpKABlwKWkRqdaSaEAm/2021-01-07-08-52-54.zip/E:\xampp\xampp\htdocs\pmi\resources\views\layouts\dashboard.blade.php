@extends('layouts.admin') 

@section('title')
Dashboard SimpaduPMI
@endsection