<footer class="main-footer">
    <div class="footer-left">
      Crafted By <a href="https://pelitacipta.com/">Pelita Cipta Informatika</a>
    </div>
    <div class="footer-right">
        simpadupmi 2.0
    </div>
</footer><?php /**PATH E:\xampp\xampp\htdocs\pmi\resources\views/layouts/part-admin/4-footer.blade.php ENDPATH**/ ?>