@extends('layouts.admin') 

@section('title')
Dashboard Simpadu
@endsection