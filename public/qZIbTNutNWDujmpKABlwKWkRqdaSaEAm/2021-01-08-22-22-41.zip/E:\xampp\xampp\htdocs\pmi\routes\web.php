<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\Backup\BackupController as BackupController;
use App\Http\Controllers\Role\UserController as UserController;
use App\Http\Controllers\Role\PermissionController as PermissionController; 
use App\Http\Controllers\Role\RoleController as RoleController;

use App\Http\Controllers\PostPage\CategoryController as CategoryController;
use App\Http\Controllers\PostPage\PageController as PageController;
use App\Http\Controllers\PostPage\PostController as PostController;
use App\Http\Controllers\PostPage\PengumumanController as PengumumanController;
use App\Http\Controllers\Sistem\SipController as SipController;
use App\Http\Controllers\Sistem\DirektoriController as DirektoriController;
use App\Http\Controllers\Sistem\MasterKategoriLineController as MasterKategoriLineController;
use App\Http\Controllers\Sistem\MasterPengirimController as MasterPengirimController;
use App\Http\Controllers\Sistem\MasterJabatanController as MasterJabatanController;
use App\Http\Controllers\Sistem\ProvinsiController as ProvinsiController;
use App\Http\Controllers\Sistem\KabKotaController as KabKotaController;
use App\Http\Controllers\Sistem\KecamatanController as KecamatanController;

use App\Http\Controllers\Sistem\JadwalPetugasController as JadwalPetugasController;
use App\Http\Controllers\Sistem\JadwalKeberangkatanController as JadwalKeberangkatanController;
use App\Http\Controllers\Sistem\JadwalKedatanganController as JadwalKedatanganController;

use App\Http\Controllers\Sistem\KedatanganController as KedatanganController;
use App\Http\Controllers\Sistem\PengaduanController as PengaduanController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
})->name('home');

Route::group(['middleware' => [
    'auth:sanctum', 'verified'
]], function(){

    Route::get('/proses-backup', [BackupController::class, 'backup'])->name('backup_process');
    Route::get('/backup', [BackupController::class, 'index'])->name('backup_index');
    // Route::get('/{filename}', [BackupController::class, 'download'])->name('backup_download');
    Route::post('/backup-delete', [BackupController::class, 'delete'])->name('backup_delete');
    

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/user/index', [UserController::class, 'index'])->name('user_index');
    Route::get('/user/create', [UserController::class, 'create'])->name('user_create');
    Route::post('/user/store', [UserController::class, 'store'])->name('user_store');
    Route::get('/user/edit/{id}', [UserController::class, 'edit'])->name('user_edit');
    Route::post('/user/update/{id}', [UserController::class, 'update'])->name('user_update');
    Route::post('/user/delete', [UserController::class, 'delete'])->name('user_delete');


    Route::get('/user/permission', [PermissionController::class, 'index'])->name('permission_index');
    Route::post('/user/permission/store', [PermissionController::class, 'store'])->name('permission_store');
    Route::get('/user/permission/edit/{id}', [PermissionController::class, 'edit'])->name('permission_edit');
    Route::post('/user/permission/update/{id}', [PermissionController::class, 'update'])->name('permission_update');
    Route::post('/user/permission/delete', [PermissionController::class, 'delete_index'])->name('permission_delete_index');

    Route::get('/user/role', [RoleController::class, 'index'])->name('role_index');
    Route::get('/user/role/create', [RoleController::class, 'create'])->name('role_create');
    Route::get('/user/role/edit/{id}', [RoleController::class, 'edit'])->name('role_edit');
    Route::post('/user/role/update/{id}', [RoleController::class, 'update'])->name('role_update');
    Route::post('/user/role/store', [RoleController::class, 'store'])->name('role_store');
    Route::post('/user/role/delete', [RoleController::class, 'delete_index'])->name('role_delete_index');

    Route::get('/page', [PageController::class, 'index'])->name('page_index');
    Route::get('/page/sampah', [PageController::class, 'sampah'])->name('page_sampah');
    Route::get('/page/create', [PageController::class, 'create'])->name('page_create');
    Route::get('/page/edit/{id}', [PageController::class, 'edit'])->name('page_edit');
    Route::get('/page/filter', [PageController::class, 'search_index'])->name('page_search');
    Route::get('/page/sampah/filter', [PageController::class, 'search_sampah'])->name('page_search_sampah');
    Route::get('/page/preview/{id}', [PageController::class, 'preview'])->name('page_preview');
    Route::post('/page/update/{id}', [PageController::class, 'update'])->name('page_update');
    Route::post('/page/store', [PageController::class, 'store'])->name('page_store');
    Route::post('/page/softdelete', [PageController::class, 'softdelete'])->name('page_softdelete');
    Route::post('/page/restore', [PageController::class, 'restore'])->name('page_restore');
    Route::post('/page/delete', [PageController::class, 'delete'])->name('page_delete');

    Route::get('/pengumuman', [PengumumanController::class, 'index'])->name('pengumuman_index');
    Route::get('/pengumuman/sampah', [PengumumanController::class, 'sampah'])->name('pengumuman_sampah');
    Route::get('/pengumuman/create', [PengumumanController::class, 'create'])->name('pengumuman_create');
    Route::get('/pengumuman/edit/{id}', [PengumumanController::class, 'edit'])->name('pengumuman_edit');
    Route::get('/pengumuman/filter', [PengumumanController::class, 'search_index'])->name('pengumuman_search');
    Route::get('/pengumuman/sampah/filter', [PengumumanController::class, 'search_sampah'])->name('pengumuman_search_sampah');
    Route::get('/pengumuman/preview/{id}', [PengumumanController::class, 'preview'])->name('pengumuman_preview');
    Route::post('/pengumuman/update/{id}', [PengumumanController::class, 'update'])->name('pengumuman_update');
    Route::post('/pengumuman/store', [PengumumanController::class, 'store'])->name('pengumuman_store');
    Route::post('/pengumuman/softdelete', [PengumumanController::class, 'softdelete'])->name('pengumuman_softdelete');
    Route::post('/pengumuman/restore', [PengumumanController::class, 'restore'])->name('pengumuman_restore');
    Route::post('/pengumuman/delete', [PengumumanController::class, 'delete'])->name('pengumuman_delete');

    Route::get('/post', [PostController::class, 'index'])->name('post_index');
    Route::get('/post/sampah', [PostController::class, 'sampah'])->name('post_sampah');
    Route::get('/post/create', [PostController::class, 'create'])->name('post_create');
    Route::get('/post/edit/{id}', [PostController::class, 'edit'])->name('post_edit');
    Route::get('/post/filter', [PostController::class, 'search_index'])->name('post_search');
    Route::get('/post/sampah/filter', [PostController::class, 'search_sampah'])->name('post_search_sampah');
    Route::get('/post/preview/{id}', [PostController::class, 'preview'])->name('post_preview');
    Route::post('/post/update/{id}', [PostController::class, 'update'])->name('post_update');
    Route::post('/post/store', [PostController::class, 'store'])->name('post_store');
    Route::post('/post/softdelete', [PostController::class, 'softdelete'])->name('post_softdelete');
    Route::post('/post/restore', [PostController::class, 'restore'])->name('post_restore');
    Route::post('/post/delete', [PostController::class, 'delete'])->name('post_delete');

    Route::get('/post/category', [CategoryController::class, 'index'])->name('category_index');
    Route::get('/post/category/create', [CategoryController::class, 'create'])->name('category_create');
    Route::get('/post/category/edit/{id}', [CategoryController::class, 'edit'])->name('category_edit');
    Route::get('/post/category/filter', [CategoryController::class, 'search'])->name('category_search');
    Route::post('/post/category/update/{id}', [CategoryController::class, 'update'])->name('category_update');
    Route::post('/post/category/store', [CategoryController::class, 'store'])->name('category_store');
    Route::post('/post/category/delete', [CategoryController::class, 'delete_index'])->name('category_delete_index');

    // Sistem

    // MASTER

    // Kategori Line

    Route::get('/master/{slug}', [MasterKategoriLineController::class, 'index'])->name('master_index');
    
    Route::post('/master/store', [MasterKategoriLineController::class, 'store'])->name('master_store');
    Route::get('/master/{slug}/edit/{id}', [MasterKategoriLineController::class, 'edit'])->name('master_edit');
    Route::post('/master/update', [MasterKategoriLineController::class, 'update'])->name('master_update');
    Route::post('/master/delete', [MasterKategoriLineController::class, 'delete'])->name('master_delete');

    // Kategori Line JSON
    Route::get('/master/sektor/json', [MasterKategoriLineController::class, 'sektor_json'])->name('sektor_json');
    Route::get('/master/masalah/json', [MasterKategoriLineController::class, 'masalah_json'])->name('masalah_json');
    Route::get('/master/jenis-pulang/json', [MasterKategoriLineController::class, 'jenisPulang_json'])->name('jenisPulang_json');
    Route::get('/master/pendidikan/json', [MasterKategoriLineController::class, 'pendidikan_json'])->name('pendidikan_json');
    Route::get('/master/pekerjaan/json', [MasterKategoriLineController::class, 'pekerjaan_json'])->name('pekerjaan_json');
    Route::get('/master/negara/json', [MasterKategoriLineController::class, 'negara_json'])->name('negara_json');
    Route::get('/master/bandara/json', [MasterKategoriLineController::class, 'bandara_json'])->name('bandara_json');
    Route::get('/master/pesawat/json', [MasterKategoriLineController::class, 'pesawat_json'])->name('pesawat_json');
    Route::get('/master/imigrasi/json', [MasterKategoriLineController::class, 'imigrasi_json'])->name('imigrasi_json');
    Route::get('/master/pengirim/json', [MasterKategoriLineController::class, 'pengirim_json'])->name('pengirim_json');

    // Pengirim
    Route::get('/mst/pengirim/json', [MasterPengirimController::class, 'index_json'])->name('pengirim_json');
    Route::get('/mst/pengirim', [MasterPengirimController::class, 'index'])->name('pengirim_index');
    Route::get('/mst/pengirim/create', [MasterPengirimController::class, 'create'])->name('pengirim_create');
    Route::get('/mst/pengirim/detail/{id}', [MasterPengirimController::class, 'detail'])->name('pengirim_detail');
    Route::get('/mst/pengirim/edit/{id}', [MasterPengirimController::class, 'edit'])->name('pengirim_edit');
    Route::post('/mst/pengirim/update', [MasterPengirimController::class, 'update'])->name('pengirim_update');
    Route::post('/mst/pengirim/store', [MasterPengirimController::class, 'store'])->name('pengirim_store');
    Route::post('/mst/pengirim/delete', [MasterPengirimController::class, 'delete'])->name('pengirim_delete');

    // Jabatan
    Route::get('/mst/jabatan/json', [MasterJabatanController::class, 'index_json'])->name('jabatan_json');
    Route::get('/mst/jabatan', [MasterJabatanController::class, 'index'])->name('jabatan_index');
    Route::get('/mst/jabatan/create', [MasterJabatanController::class, 'create'])->name('jabatan_create');
    Route::get('/mst/jabatan/detail/{id}', [MasterJabatanController::class, 'detail'])->name('jabatan_detail');
    Route::get('/mst/jabatan/edit/{id}', [MasterJabatanController::class, 'edit'])->name('jabatan_edit');
    Route::post('/mst/jabatan/update', [MasterJabatanController::class, 'update'])->name('jabatan_update');
    Route::post('/mst/jabatan/store', [MasterJabatanController::class, 'store'])->name('jabatan_store');
    Route::post('/mst/jabatan/delete', [MasterJabatanController::class, 'delete'])->name('jabatan_delete');

    // Provinsi
    Route::get('/mst/provinsi/json', [ProvinsiController::class, 'index_json'])->name('provinsi_json');
    Route::get('/mst/provinsi', [ProvinsiController::class, 'index'])->name('provinsi_index');
    Route::get('/mst/provinsi/create', [ProvinsiController::class, 'create'])->name('provinsi_create');
    Route::get('/mst/provinsi/edit/{id}', [ProvinsiController::class, 'edit'])->name('provinsi_edit');
    Route::post('/mst/provinsi/update/{id}', [ProvinsiController::class, 'update'])->name('provinsi_update');
    Route::post('/mst/provinsi/store', [ProvinsiController::class, 'store'])->name('provinsi_store');
    Route::post('/mst/provinsi/delete', [ProvinsiController::class, 'delete'])->name('provinsi_delete');

    // Kabkota
    Route::get('/mst/kabkota/json', [KabKotaController::class, 'index_json'])->name('kabkota_json');
    Route::get('/mst/kabkota', [KabKotaController::class, 'index'])->name('kabkota_index');
    Route::get('/mst/kabkota/create', [KabKotaController::class, 'create'])->name('kabkota_create');
    Route::get('/mst/kabkota/edit/{id}', [KabKotaController::class, 'edit'])->name('kabkota_edit');
    Route::post('/mst/kabkota/update/{id}', [KabKotaController::class, 'update'])->name('kabkota_update');
    Route::post('/mst/kabkota/store', [KabKotaController::class, 'store'])->name('kabkota_store');
    Route::post('/mst/kabkota/delete', [KabKotaController::class, 'delete'])->name('kabkota_delete');

    // Kecamatan
    Route::get('/mst/kecamatan/json', [KecamatanController::class, 'index_json'])->name('kecamatan_json');
    Route::get('/mst/kecamatan', [KecamatanController::class, 'index'])->name('kecamatan_index');
    Route::get('/mst/kecamatan/create', [KecamatanController::class, 'create'])->name('kecamatan_create');
    Route::get('/mst/kecamatan/edit/{id}', [KecamatanController::class, 'edit'])->name('kecamatan_edit');
    Route::post('/mst/kecamatan/update/{id}', [KecamatanController::class, 'update'])->name('kecamatan_update');
    Route::post('/mst/kecamatan/store', [KecamatanController::class, 'store'])->name('kecamatan_store');
    Route::post('/mst/kecamatan/delete', [KecamatanController::class, 'delete'])->name('kecamatan_delete');

    // SIP
    Route::get('/sip/json', [SipController::class, 'index_json'])->name('sip_json');
    Route::get('/sip', [SipController::class, 'index'])->name('sip_index');
    Route::get('/sip/create', [SipController::class, 'create'])->name('sip_create');
    Route::get('/sip/detail/{id}', [SipController::class, 'detail'])->name('sip_detail');
    Route::get('/sip/edit/{id}', [SipController::class, 'edit'])->name('sip_edit');
    Route::post('/sip/update/{id}', [SipController::class, 'update'])->name('sip_update');
    Route::post('/sip/store', [SipController::class, 'store'])->name('sip_store');
    Route::post('/sip/delete', [SipController::class, 'delete'])->name('sip_delete');

    // Jadwal Petugas
    Route::get('/jadwal/petugas/json', [JadwalPetugasController::class, 'index_json'])->name('jadwal_petugas_json');
    Route::get('/jadwal/petugas', [JadwalPetugasController::class, 'index'])->name('jadwal_petugas_index');
    Route::get('/jadwal/petugas/create', [JadwalPetugasController::class, 'create'])->name('jadwal_petugas_create');
    Route::get('/jadwal/petugas/detail/{id}', [JadwalPetugasController::class, 'detail'])->name('jadwal_petugas_detail');
    Route::get('/jadwal/petugas/edit/{id}', [JadwalPetugasController::class, 'edit'])->name('jadwal_petugas_edit');
    Route::post('/jadwal/petugas/update', [JadwalPetugasController::class, 'update'])->name('jadwal_petugas_update');
    Route::post('/jadwal/petugas/store', [JadwalPetugasController::class, 'store'])->name('jadwal_petugas_store');
    Route::post('/jadwal/petugas/delete', [JadwalPetugasController::class, 'delete'])->name('jadwal_petugas_delete');

    // Jadwal Kedatangan
    Route::get('/jadwal/kedatangan/json', [JadwalKedatanganController::class, 'index_json'])->name('jadwal_kedatangan_json');
    Route::get('/jadwal/kedatangan', [JadwalKedatanganController::class, 'index'])->name('jadwal_kedatangan_index');
    Route::get('/jadwal/kedatangan/create', [JadwalKedatanganController::class, 'create'])->name('jadwal_kedatangan_create');
    Route::get('/jadwal/kedatangan/detail/{id}', [JadwalKedatanganController::class, 'detail'])->name('jadwal_kedatangan_detail');
    Route::get('/jadwal/kedatangan/edit/{id}', [JadwalKedatanganController::class, 'edit'])->name('jadwal_kedatangan_edit');
    Route::post('/jadwal/kedatangan/update', [JadwalKedatanganController::class, 'update'])->name('jadwal_kedatangan_update');
    Route::post('/jadwal/kedatangan/store', [JadwalKedatanganController::class, 'store'])->name('jadwal_kedatangan_store');
    Route::post('/jadwal/kedatangan/delete', [JadwalKedatanganController::class, 'delete'])->name('jadwal_kedatangan_delete');


    // keberangkatan
    Route::get('/jadwal/keberangkatan/json', [JadwalKeberangkatanController::class, 'index_json'])->name('jadwal_keberangkatan_json');
    Route::get('/jadwal/keberangkatan', [JadwalKeberangkatanController::class, 'index'])->name('jadwal_keberangkatan_index');
    Route::get('/jadwal/keberangkatan/create', [JadwalKeberangkatanController::class, 'create'])->name('jadwal_keberangkatan_create');
    Route::get('/jadwal/keberangkatan/detail/{id}', [JadwalKeberangkatanController::class, 'detail'])->name('jadwal_keberangkatan_detail');
    Route::get('/jadwal/keberangkatan/edit/{id}', [JadwalKeberangkatanController::class, 'edit'])->name('jadwal_keberangkatan_edit');
    Route::post('/jadwal/keberangkatan/update', [JadwalKeberangkatanController::class, 'update'])->name('jadwal_keberangkatan_update');
    Route::post('/jadwal/keberangkatan/store', [JadwalKeberangkatanController::class, 'store'])->name('jadwal_keberangkatan_store');
    Route::post('/jadwal/keberangkatan/delete', [JadwalKeberangkatanController::class, 'delete'])->name('jadwal_keberangkatan_delete');
    
    Route::get('/jadwal/keberangkatan/getkabkota', [KedatanganController::class, 'getKabKota'])->name('jadwal_keberangkatan_get_kab');
    Route::get('/jadwal/keberangkatan/getkecamatan', [KedatanganController::class, 'getKecamatan'])->name('jadwal_keberangkatan_get_kecamatan');
    Route::get('/jadwal/keberangkatan/getdesa', [KedatanganController::class, 'getDesa'])->name('jadwal_keberangkatan_get_desa');
    Route::get('/jadwal/keberangkatan/getpekerjaan', [KedatanganController::class, 'getPekerjaan'])->name('jadwal_keberangkatan_get_pekerjaan');


    // Kedatangan
    Route::get('/kedatangan/json', [KedatanganController::class, 'index_json'])->name('kedatangan_json');
    Route::get('/kedatangan', [KedatanganController::class, 'index'])->name('kedatangan_index');
    Route::get('/kedatangan/create', [KedatanganController::class, 'create'])->name('kedatangan_create');
    Route::get('/kedatangan/detail/{id}', [KedatanganController::class, 'detail'])->name('kedatangan_detail');
    Route::get('/kedatangan/edit/{id}', [KedatanganController::class, 'edit'])->name('kedatangan_edit');
    Route::post('/kedatangan/update', [KedatanganController::class, 'update'])->name('kedatangan_update');
    Route::post('/kedatangan/store', [KedatanganController::class, 'store'])->name('kedatangan_store');
    Route::post('/kedatangan/delete', [KedatanganController::class, 'delete'])->name('kedatangan_delete');
    
    Route::get('/kedatangan/getkabkota', [KedatanganController::class, 'getKabKota'])->name('kedatangan_get_kab');
    Route::get('/kedatangan/getkecamatan', [KedatanganController::class, 'getKecamatan'])->name('kedatangan_get_kecamatan');
    Route::get('/kedatangan/getdesa', [KedatanganController::class, 'getDesa'])->name('kedatangan_get_desa');
    Route::get('/kedatangan/getpekerjaan', [KedatanganController::class, 'getPekerjaan'])->name('kedatangan_get_pekerjaan');
    
    // Pengaduan
    Route::get('/pengaduan/json', [PengaduanController::class, 'index_json'])->name('pengaduan_json');
    Route::get('/pengaduan', [PengaduanController::class, 'index'])->name('pengaduan_index');
    Route::get('/pengaduan/create', [PengaduanController::class, 'create'])->name('pengaduan_create');
    Route::get('/pengaduan/detail/{id}', [PengaduanController::class, 'detail'])->name('pengaduan_detail');
    Route::get('/pengaduan/edit/{id}', [PengaduanController::class, 'edit'])->name('pengaduan_edit');
    Route::post('/pengaduan/update', [PengaduanController::class, 'update'])->name('pengaduan_update');
    Route::post('/pengaduan/store', [PengaduanController::class, 'store'])->name('pengaduan_store');
    Route::post('/pengaduan/delete', [PengaduanController::class, 'delete'])->name('pengaduan_delete');
    Route::get('/pengaduan/sampah-json', [PengaduanController::class, 'sampah_json'])->name('pengaduan_sampah_json');
    Route::get('/pengaduan/sampah', [PengaduanController::class, 'index_sampah'])->name('pengaduan_sampah');
    Route::post('/pengaduan/restore', [PengaduanController::class, 'restore'])->name('pengaduan_restore');
    Route::post('/pengaduan/destroy', [PengaduanController::class, 'destroy'])->name('pengaduan_destroy');
    Route::get('/pengaduan/pptkis', [PengaduanController::class, 'getDetailPptkis'])->name('pengaduan_pptkis');

    // Route::put('/pengaduan/filekrono', [PengaduanController::class, 'uploadFileKrono'])->name('pengaduan_file_krono');
    Route::get('/pengaduan/getkabkota', [PengaduanController::class, 'getKabKota'])->name('pengaduan_get_kab');
    Route::get('/pengaduan/getkecamatan', [PengaduanController::class, 'getKecamatan'])->name('pengaduan_get_kecamatan');
    Route::get('/pengaduan/getdesa', [PengaduanController::class, 'getDesa'])->name('pengaduan_get_desa');
    Route::get('/pengaduan/getpekerjaan', [PengaduanController::class, 'getPekerjaan'])->name('pengaduan_get_pekerjaan');

    // Penanganan Pengaduan

    Route::get('/pengaduan/tindak-lanjut/{id}', [PengaduanController::class, 'penanganan'])->name('pengaduan_penanganan');
    Route::post('/pengaduan/tindak-lanjut/store/{id}', [PengaduanController::class, 'penanganan_store'])->name('pengaduan_penanganan_store');
    //  DIREKTORI

    // Disnaker
    Route::get('/direktori/json', [DirektoriController::class, 'direktori_json'])->name('direktori_json');

    Route::get('/direktori/disnaker', [DirektoriController::class, 'disnaker_index'])->name('disnaker_index');
    Route::get('/direktori/disnaker/create', [DirektoriController::class, 'disnaker_create'])->name('disnaker_create');
    Route::get('/direktori/disnaker/detail/{id}', [DirektoriController::class, 'disnaker_detail'])->name('disnaker_detail');
    Route::get('/direktori/disnaker/edit/{id}', [DirektoriController::class, 'disnaker_edit'])->name('disnaker_edit');
    Route::post('/direktori/disnaker/update/{id}', [DirektoriController::class, 'disnaker_update'])->name('disnaker_update');
    Route::post('/direktori/disnaker/store', [DirektoriController::class, 'disnaker_store'])->name('disnaker_store');
    Route::post('/direktori/disnaker/delete', [DirektoriController::class, 'disnaker_delete'])->name('disnaker_delete');

    // BLK
    Route::get('/direktori/blk', [DirektoriController::class, 'blk_index'])->name('blk_index');
    Route::get('/direktori/blk/create', [DirektoriController::class, 'blk_create'])->name('blk_create');
    Route::get('/direktori/blk/detail/{id}', [DirektoriController::class, 'blk_detail'])->name('blk_detail');
    Route::get('/direktori/blk/edit/{id}', [DirektoriController::class, 'blk_edit'])->name('blk_edit');
    Route::post('/direktori/blk/update/{id}', [DirektoriController::class, 'blk_update'])->name('blk_update');
    Route::post('/direktori/blk/store', [DirektoriController::class, 'blk_store'])->name('blk_store');
    Route::post('/direktori/blk/delete', [DirektoriController::class, 'blk_delete'])->name('blk_delete');

    // KBRI
    Route::get('/direktori/kbri', [DirektoriController::class, 'kbri_index'])->name('kbri_index');
    Route::get('/direktori/kbri/create', [DirektoriController::class, 'kbri_create'])->name('kbri_create');
    Route::get('/direktori/kbri/detail/{id}', [DirektoriController::class, 'kbri_detail'])->name('kbri_detail');
    Route::get('/direktori/kbri/edit/{id}', [DirektoriController::class, 'kbri_edit'])->name('kbri_edit');
    Route::post('/direktori/kbri/update/{id}', [DirektoriController::class, 'kbri_update'])->name('kbri_update');
    Route::post('/direktori/kbri/store', [DirektoriController::class, 'kbri_store'])->name('kbri_store');
    Route::post('/direktori/kbri/delete', [DirektoriController::class, 'kbri_delete'])->name('kbri_delete');

    // P3MI
    Route::get('/direktori/p3mi', [DirektoriController::class, 'p3mi_index'])->name('p3mi_index');
    Route::get('/direktori/p3mi/create', [DirektoriController::class, 'p3mi_create'])->name('p3mi_create');
    Route::get('/direktori/p3mi/detail/{id}', [DirektoriController::class, 'p3mi_detail'])->name('p3mi_detail');
    Route::get('/direktori/p3mi/edit/{id}', [DirektoriController::class, 'p3mi_edit'])->name('p3mi_edit');
    Route::post('/direktori/p3mi/update/{id}', [DirektoriController::class, 'p3mi_update'])->name('p3mi_update');
    Route::post('/direktori/p3mi/store', [DirektoriController::class, 'p3mi_store'])->name('p3mi_store');
    Route::post('/direktori/p3mi/delete', [DirektoriController::class, 'p3mi_delete'])->name('p3mi_delete');

    // P3MI
    Route::get('/direktori/lsp', [DirektoriController::class, 'lsp_index'])->name('lsp_index');
    Route::get('/direktori/lsp/create', [DirektoriController::class, 'lsp_create'])->name('lsp_create');
    Route::get('/direktori/lsp/detail/{id}', [DirektoriController::class, 'lsp_detail'])->name('lsp_detail');
    Route::get('/direktori/lsp/edit/{id}', [DirektoriController::class, 'lsp_edit'])->name('lsp_edit');
    Route::post('/direktori/lsp/update/{id}', [DirektoriController::class, 'lsp_update'])->name('lsp_update');
    Route::post('/direktori/lsp/store', [DirektoriController::class, 'lsp_store'])->name('lsp_store');
    Route::post('/direktori/lsp/delete', [DirektoriController::class, 'lsp_delete'])->name('lsp_delete');
    
});

// Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
//     return view('layouts/app');
// })->name('dashboard');


// Order is important in route file. Put the most generic in last.
Route::get('/browse/filter', [PostController::class, 'cari'])->name('post_cari');
Route::get('/p/{slug}', [PageController::class, 'show'])->name('page_show');
Route::get('/announcement', [PengumumanController::class, 'front'])->name('pengumuman_front');
Route::get('/announcement/{slug}', [PengumumanController::class, 'show'])->name('pengumuman_show');
Route::get('/portal', [PostController::class, 'portal'])->name('post_portal');
Route::get('/{kategori}/{slug}', [PostController::class, 'show'])->name('post_show');
Route::get('/{kategori}', [PostController::class, 'post_category'])->name('post_category');

